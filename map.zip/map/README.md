## echarts实现北京西城区地图Demo

![image login](https://github.com/zhangqian00/echarts-map-xicheng/blob/master/img/demo.png)

#### 由于地图json文件，是异步获取的，所以查看demo时，需要服务器访问方式查看